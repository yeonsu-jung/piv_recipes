# %%
from openpiv import tools, pyprocess, validation, filters, scaling 
from PIL import Image
from argparse import Namespace

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re
import os
import imageio as io
import logging

# %%
class ParticleImage:    
    def __init__(self, folder_path):
        self.path = folder_path
        self.param_string_list = [x for x in os.listdir(self.path) if os.path.isdir(os.path.join(folder_path,x)) and not x.startswith('_')]        
        self.param_dict_list = []

        for x in self.param_string_list:
            self.param_dict_list.append(self.param_string_to_dictionary(x))
        
        self.piv_param = {
            "winsize": 48,
            "searchsize": 52,
            "overlap": 24,
            "dt": 0.0001,
            "image_check": False,    
            "show_vertical_profiles": False,            
            "figure_export_name": '_quick_piv.tiff',
            "text_export_name": '_quick_piv.txt',
            "scale_factor": 1,            
            "pixel_density": 36.74,
            "arrow_width": 0.02,
            "show_result": True,        
            "upper_bound": 2000, # (mm/s)
            "lower_bound": -2000, # (mm/s) 
        }
        self.piv_dict_list = self.param_dict_list

    def set_piv_list(self,exp_cond_dict):        
        self.piv_dict_list = [x for x in self.param_dict_list if exp_cond_dict.items() <= x.items()]        

    def param_string_to_dictionary(self,pstr):
        running_parameter = re.findall("_[a-z]+[0-9]+[.]*[0-9]*", pstr, re.IGNORECASE)
        sample_parameter = pstr.replace("img_","")

        for k in running_parameter:
            sample_parameter = sample_parameter.replace(k,"")

        sample_parameter = sample_parameter.replace('_01-18',"")

        param_dict = {'sample': sample_parameter}
        for k in running_parameter:
            kk = re.findall('[a-x]+', k,re.IGNORECASE)
            vv = re.findall('[0-9]+[.]*[0-9]*', k,re.IGNORECASE)
            param_dict[kk[0]] = float(vv[0])

        param_dict['path'] = pstr
        return param_dict

    def read_two_images(self,search_dict,index_a = 100,index_b = 101):
        location_path = [x['path'] for x in self.piv_dict_list if search_dict.items() <= x.items()]
        print('Read image from:', *location_path)

        file_a_path = os.path.join(self.path,*location_path,'frame_%06d.tiff' %index_a)
        file_b_path = os.path.join(self.path,*location_path,'frame_%06d.tiff' %index_b)        

        try:              
            img_a = Image.open(file_a_path)
            img_b = Image.open(file_b_path)
        except FileNotFoundError:
            print('No such file: ' + file_a_path)
            print('No such file: ' + file_b_path)

        return img_a, img_b

    def check_image_pair():
        return True

    def show_piv_param(self):
        print("- PIV parameters -")
        for x, y in self.piv_param.items():
            print(x +":", y)    

    def quick_piv(self,camera_position,sensor_position,index_a = 100, index_b = 101):
        self.show_piv_param()
                
        search_dict = {"pos": camera_position,"VOFFSET": (sensor_position - 1)*80 }        
        img_a, img_b = self.read_two_images(search_dict,index_a=index_a,index_b=index_b)

        img_a = np.array(img_a).T
        img_b = np.array(img_b).T

        u_std = self.run_piv(img_a,img_b,**self.piv_param)
        
        if u_std > 480:
            img_a, img_b = self.read_two_images(search_dict,index_a=index_a+1,index_b=index_b+1)
            img_a = np.array(img_a).T
            img_b = np.array(img_b).T
            
            u_std = self.run_piv(img_a,img_b,**self.piv_param)        

    def quick_piv_by_key(self, search_dict, index_a = 100, index_b = 101):
        self.show_piv_param()
        
        ns = Namespace(**self.piv_param)

        img_a, img_b = self.read_two_images(search_dict,index_a=index_a,index_b=index_b)

        img_a = np.array(img_a).T
        img_b = np.array(img_b).T                
            
        u0, v0, sig2noise = pyprocess.extended_search_area_piv(img_a.astype(np.int32),
                                                            img_b.astype(np.int32),
                                                            window_size=ns.winsize,
                                                            overlap=ns.overlap, 
                                                            dt=ns.dt, 
                                                            search_area_size=ns.searchsize, 
                                                            sig2noise_method='peak2peak')

        x, y = pyprocess.get_coordinates(image_size=img_a.shape, 
                                        search_area_size=ns.searchsize,                                    
                                        overlap=ns.overlap)

        x, y, u0, v0 = scaling.uniform(x, y, u0, v0, scaling_factor = ns.pixel_density) # no. pixel per distance

        u0, v0, mask = validation.global_val(u0,v0,(0,200),(-200,200))

        u1, v1, mask = validation.sig2noise_val( u0, v0, 
                                                sig2noise, 
                                                threshold = 1.01)

        u3, v3 = filters.replace_outliers( u1, v1,
                                        method='localmean',
                                        max_iter=500,
                                        kernel_size=3)
        

        #save in the simple ASCII table format
        # if np.std(u3) < 480:
        tools.save(x, y, u3, v3, sig2noise,mask, ns.text_export_name)
        
        if ns.image_check == True:
            fig,ax = plt.subplots(2,1,figsize=(24,12))
            ax[0].imshow(frame_a)
            ax[1].imshow(frame_b)

        io.imwrite(ns.figure_export_name,img_a)

        if ns.show_result == True:
            fig, ax = plt.subplots(figsize=(24,12))
            tools.display_vector_field(ns.text_export_name, 
                                        ax=ax, scaling_factor= ns.pixel_density, 
                                        scale=ns.scale_factor, # scale defines here the arrow length
                                        width=ns.arrow_width, # width is the thickness of the arrow
                                        on_img=True, # overlay on the image
                                        image_name= ns.figure_export_name)
            fig.savefig(ns.figure_export_name)       

        if ns.show_vertical_profiles:
            field_shape = pyprocess.get_field_shape(image_size=img_a.shape,search_area_size=ns.searchsize,overlap=ns.overlap)
            vertical_profiles(ns.text_export_name,field_shape)
        
        print('Std of u3: %.3f' %np.std(u3))
        print('Mean of u3: %.3f' %np.mean(u3))

        return np.std(u3)


    # u_std = self.run_piv(img_a,img_b,**self.piv_param)
    
    # if u_std > 480:
    #     img_a, img_b = self.read_two_images(search_dict,index_a=index_a+1,index_b=index_b+1)
    #     img_a = np.array(img_a).T
    #     img_b = np.array(img_b).T
        
    #     u_std = self.run_piv(img_a,img_b,**self.piv_param)        

    def stitch_images(self):
        entire_image_path = os.path.join(self.path,'_entire_image.png')

        try:
            im = Image.open(entire_image_path)        
            im.show(entire_image_path)            

        except FileNotFoundError:
            garo = 1408
            sero = (1296)*11
            entire_image = np.zeros((sero,garo))
            for param_string in self.param_string_list:
                # CHECK IMAGE VALIDITY ?
                img_a_name = 'frame_000102.tiff'
                img_b_name = 'frame_000103.tiff'

                param_dict = self.param_string_to_dictionary(param_string)

                try:
                    file_path_a = os.path.join(folder_path,param_string,img_a_name)
                    file_path_b = os.path.join(folder_path,param_string,img_b_name)
                    img_a = io.imread(file_path_a)
                    # img_b = io.imread(file_path_b)
                except:
                    file_path_a = os.path.join(folder_path,'img_' + param_string,img_a_name)
                    file_path_b = os.path.join(folder_path,'img_' + param_string,img_b_name)

                    img_a = io.imread(file_path_a)
                    # img_b = io.imread(file_path_b)
                    
                position = int(param_dict['pos'])
                v_offset = int(param_dict['VOFFSET'])

                start_index = (position-1)*1296 + (v_offset//80)*108
                end_index = start_index + 108

                entire_image[start_index:end_index,:] = img_a

            io.imwrite(entire_image_path,entire_image.T)
            im = Image.open(entire_image_path)
            im.show(entire_image_path)

        return im

    def piv_upper_region(self,camera_position,sensor_position,index_a = 100, index_b = 101,surface_index = 360):
        
        search_dict = {"pos": camera_position,"VOFFSET": (sensor_position - 1)*80 }
        img_a, img_b = self.read_two_images(search_dict,index_a=index_a,index_b=index_b)                      

        img_a = np.array(img_a)
        img_b = np.array(img_b)
        
        img_a = img_a[:,0:surface_index].T
        img_b = img_b[:,0:surface_index].T        

        u_std = self.run_piv(img_a,img_b,**self.piv_param)
        if u_std > 480:
            img_a, img_b = self.read_two_images(camera_position,sensor_position,index_a=index_a+1,index_b=index_b+1)
            img_a = np.array(img_a)
            img_b = np.array(img_b)

            img_a = img_a[:,0:surface_index].T
            img_b = img_b[:,0:surface_index].T
            u_std = self.run_piv(img_a,img_b,**self.piv_param)

    def piv_lower_region(self,camera_position,sensor_position,index_a = 100, index_b = 101,surface_index = 360):
        
        search_dict = {"pos": camera_position,"VOFFSET": (sensor_position - 1)*80 }
        img_a, img_b = self.read_two_images(search_dict,index_a=index_a,index_b=index_b)

        # img_a = np.array(img_a.rotate(-1.364))
        # img_b = np.array(img_b.rotate(-1.364))

        img_a = np.array(img_a)
        img_b = np.array(img_b)

        img_a = img_a[:,-surface_index:-1].T
        img_b = img_b[:,-surface_index:-1].T

        u_std = self.run_piv(img_a,img_b,**self.piv_param)
        if u_std > 480:
            img_a, img_b = self.read_two_images(camera_position,sensor_position,index_a=index_a+1,index_b=index_b+1)
            img_a = np.array(img_a)
            img_b = np.array(img_b)

            img_a = img_a[:,-surface_index:-1].T
            img_b = img_b[:,-surface_index:-1].T
            u_std = self.run_piv(img_a,img_b,**self.piv_param)

    def fast_piv(self, pos, voffset, index_a=100,index_b=101):        
        img_a, img_b = self.read_two_images(pos,voffset,index_a = index_a,index_b=index_b)

        return 0

    def get_entire_vector_field(self,first_position=1, last_position = 11,index_a=100,index_b=101):
        self.set_piv_param({"show_result":False})
        # pos_list = [x['pos'] for x in self.param_dict_list]
        # voffset_list = [x['VOFFSET'] for x in self.param_dict_list]

        entire_x = np.empty((49,3))
        entire_y = np.empty((49,3))
        entire_u = np.empty((49,3))
        entire_v = np.empty((49,3))

        for pos in range(first_position,last_position+1,1):
            for voffset in range(1,13,1):                
                search_dict = {'pos': pos, 'VOFFSET': (voffset-1)*80}

                self.quick_piv_by_key(search_dict)
                xx,yy,uu,vv = convert_xyuv()

                entire_x = np.hstack((entire_x,xx))
                entire_y = np.hstack((entire_y,yy))
                entire_u = np.hstack((entire_u,uu))
                entire_v = np.hstack((entire_v,vv))

        np.savetxt('_entire_x.txt',entire_x[:,3:-1].T)
        np.savetxt('_entire_y.txt',entire_y[:,3:-1].T)
        np.savetxt('_entire_u.txt',entire_u[:,3:-1].T)
        np.savetxt('_entire_v.txt',entire_v[:,3:-1].T)

        self.set_piv_param({"show_result":True})

    def set_piv_param(self,param):
        for k in param:
            self.piv_param[k] = param[k]        
        
    def my_argsort(lis):
        return sorted(range(len(lis)),key=lis.__getitem__)

    def open_two_images(self,search_dict,index_a = 100,index_b = 101):
                        
        location_path = [x['path'] for x in self.piv_dict_list if search_dict.items() <= x.items()]

        file_a_path = os.path.join(self.path,*location_path,'frame_%06d.tiff' %index_a)
        file_b_path = os.path.join(self.path,*location_path,'frame_%06d.tiff' %index_b)        

        im1 = Image.open(file_a_path)
        im2 = Image.open(file_b_path)

        im1.show()
        im2.show()    

    def calculate_drag(self,start = 1, end = 1):
        entire_x = np.loadtxt('_entire_x.txt')
        entire_y = np.loadtxt('_entire_y.txt')
        entire_u = np.loadtxt('_entire_u.txt')
        entire_v = np.loadtxt('_entire_v.txt')

        left_u = entire_u[start,:]
        right_u = entire_u[-end,:]

        left_v = entire_v[start,:]
        right_v = entire_v[-end,:]

        # top_u = entire_u[3:-1,1]
        # bottom_u = entire_u[3:-1,-1]

        # top_v = entire_v[3:-1,1]
        # bottom_v = entire_v[3:-1,-1]
        
        # X = (52-24)*215*1.5*25.4/1400
        Y = (52-24)*49*1.5*25.4/1400

        # x_coord = np.linspace(0,X,215)
        y_coord = np.linspace(0,Y,49)

        fig,ax = plt.subplots(2,2)
        ax[0,0].plot(y_coord,left_u)
        ax[1,0].plot(y_coord,right_u)

        ax[0,1].plot(y_coord,left_v)
        ax[1,1].plot(y_coord,right_v)

        ax[1,0].set_xlabel('y coordinate (mm)')
        ax[0,0].set_ylabel('u (mm/s)')
        ax[1,0].set_ylabel('u (mm/s)')

        ax[0,1].set_ylabel('v (mm/s)')
        ax[1,1].set_ylabel('v (mm/s)')

        # fig,ax = plt.subplots(2,2)
        # ax[0,0].plot(x_coord,top_u)
        # ax[1,0].plot(x_coord,bottom_u)

        # ax[0,1].plot(x_coord,top_v)
        # ax[1,1].plot(x_coord,bottom_v)

        # ax[1,0].set_xlabel('y coordinate')
        # ax[0,0].set_ylabel('u (mm/s)')
        # ax[1,0].set_ylabel('u (mm/s)')

        # ax[0,1].set_ylabel('v (mm/s)')
        # ax[1,1].set_ylabel('v (mm/s)')
        rho = 1000
        delta_y = (52-24)*1.5*25.4/1400/1000
        W = 0.048
        # delta_x = (52-24)*1.5*25.4/1400/1000

        A = rho*(np.sum((left_u/1000)**2) - np.sum((right_u/1000)**2)) * delta_y * W

        mdot_1 = np.sum((left_u - right_u))/1000 * delta_y * W
        # mdot_2 = np.sum((top_v - bottom_v))/1000*delta_y

        B1 = mdot_1*np.mean(left_u)/1000 * W

        F1 = A - B1
        print('Dynamic pressure difference: %.4f (N)' %A)
        print('m dot: %.8f (kg/s)' %B1)
        print('Force (N): %.4f' %F1)  


# %%

# plt.rcParams['animation.ffmpeg_path'] = '/Users/yeonsu/opt/anaconda3/envs/piv/share/ffmpeg'

def dummy(a,b):
    print('I have done nothing.')

def run_piv(
    frame_a,
    frame_b,
    winsize = 64, # pixels, interrogation window size in frame A
    searchsize = 66,  # pixels, search in image B
    overlap = 32, # pixels, 50% overlap
    dt = 0.0001, # sec, time interval between pulses
    image_check = False,
    show_vertical_profiles = False,
    figure_export_name = '_results.png',
    text_export_name =  "_results.txt",
    scale_factor = 1,
    pixel_density = 36.74,
    arrow_width = 0.02,
    show_result = True,
    ):
           
    u0, v0, sig2noise = pyprocess.extended_search_area_piv(frame_a.astype(np.int32), 
                                                        frame_b.astype(np.int32), 
                                                        window_size=winsize, 
                                                        overlap=overlap, 
                                                        dt=dt, 
                                                        search_area_size=searchsize, 
                                                        sig2noise_method='peak2peak')

    x, y = pyprocess.get_coordinates(image_size=frame_a.shape, 
                                    search_area_size=searchsize,                                    
                                    overlap=overlap)

    u1, v1, mask = validation.sig2noise_val( u0, v0, 
                                            sig2noise, 
                                            threshold = 1.05 )

    u2, v2 = filters.replace_outliers( u1, v1,
                                    method='localmean',
                                    max_iter=10,
                                    kernel_size=3)

    x, y, u3, v3 = scaling.uniform(x, y, u2, v2,
                                scaling_factor = pixel_density) # no. pixel per distance    

    #save in the simple ASCII table format    
    if np.std(u3) < 480:
        tools.save(x, y, u3, v3, sig2noise,mask, text_export_name)
    
    if image_check == True:
        fig,ax = plt.subplots(2,1,figsize=(24,12))
        ax[0].imshow(frame_a)
        ax[1].imshow(frame_b)

    io.imwrite(figure_export_name,frame_a)

    if show_result == True:
        fig, ax = plt.subplots(figsize=(24,12))
        tools.display_vector_field(text_export_name, 
                                    ax=ax, scaling_factor= pixel_density, 
                                    scale=scale_factor, # scale defines here the arrow length
                                    width=arrow_width, # width is the thickness of the arrow
                                    on_img=True, # overlay on the image
                                    image_name= figure_export_name)
        fig.savefig(figure_export_name)       

    if show_vertical_profiles:
        field_shape = pyprocess.get_field_shape(image_size=frame_a.shape,search_area_size=searchsize,overlap=overlap)
        vertical_profiles(text_export_name,field_shape)
    
    print('Std of u3: %.3f' %np.std(u3))
    print('Mean of u3: %.3f' %np.mean(u3))

    return np.std(u3)


def vertical_profiles(text_export_name,field_shape):
    df = pd.read_csv(text_export_name,
        delimiter='\t',
        names=['x','y','u','v','s2n','mask'],
        skiprows=1)

    x_array = df.iloc[:,0].to_numpy()
    y_array = df.iloc[:,1].to_numpy()
    uv_array = df.iloc[:,2:4].to_numpy()

    num_rows = field_shape[0] # 11
    num_cols = field_shape[1] # 100

    U_array = np.sqrt(uv_array[:,0]**2+uv_array[:,0]**2).reshape(num_rows,num_cols).T        
    x_coord = x_array.reshape(num_rows,num_cols)[0,:]
    y_coord = np.flipud(y_array.reshape(num_rows,num_cols)[:,0])
    
    fig,axes = plt.subplots(4,3,figsize=(16,16))

    axes_flatten = np.ravel(axes)
    ii = 0  
    for ax in axes_flatten:            
        for i in range(ii*10,(ii+1)*10):
            if i >= num_cols:
                break
            ax.plot(U_array[i,:],y_coord,'o-',label='%.2f'%x_coord[i])
            ax.legend()
            ax.axis([0,np.max(U_array),0,np.max(y_coord)])        
        ax.set_xlabel('Velocity (mm/s)')
        ax.set_ylabel('y-coordinate (mm)')
        ii = ii + 1        
    fig.savefig('vertical_profile.png')

    # if animation_flag is True:
    #     #writer_instance = animation.writers['ffmpeg']
    #     # writer_instance = animation.FFMpegWriter(fps=60) 
    #     # Writer = animation.FFMpegWriter
    #     #Writer = animation.writers['ffmpeg']
    #     Writer = animation.FFMpegWriter(fps=15)
    #     writer = Writer(fps=15,bitrate=1800)


    #     ani_frames = []
    #     fig_ani = plt.figure()
    #     plt.xlabel('Velocity (mm/s)')
    #     plt.ylabel('y-coordinate (mm)')
    #     plt.axis([0,280,0,6])
    #     for i in range(num_cols):
    #         ani_frames.append(plt.plot(U_array[i,:],y_coord,'o-'))
            
    #     ani = animation.ArtistAnimation(fig_ani, ani_frames,
    #                 interval=10,
    #                 repeat_delay = 10,
    #                 blit=True)                    
    #     ani.save('animation.mp4',writer=writer)   

def convert_xyuv():
    saved_txt = np.loadtxt('_quick_piv.txt')
    
    xx = saved_txt[:,0]
    yy = saved_txt[:,1]
    uu = saved_txt[:,2]
    vv = saved_txt[:,3]

    xx2 = xx.reshape(49,3)
    yy2 = yy.reshape(49,3)
    uu2 = uu.reshape(49,3)
    vv2 = vv.reshape(49,3)

    return xx2,yy2,uu2,vv2

def negative(image):
    """ Return the negative of an image
    
    Parameter
    ----------
    image : 2d np.ndarray of grey levels

    Returns
    -------
    (255-image) : 2d np.ndarray of grey levels

    """
    return 255 - image
# %%

# folder_path = 'D:/ROWLAND/piv-data/2021-01-18'
# pi = ParticleImage(folder_path)
# print(pi.param_dict_list)

# # %%
# search_dict = {'sample': 'Flat_10','motor':25}

# list_original = pi.param_dict_list
# list_for_entire_piv = [x for x in list_original if search_dict.items() <= x.items()]

# print(list_for_entire_piv)
# # %%
# pi.param_dict_list = list_for_entire_piv
# # %%
# pi.get_entire_vector_field(first_position=2,last_position=5)

# # %%
# pi.calculate_drag(start = 1, end = 1)

# # %%
# pi.quick_piv(5,7)
# # %%
# search_dict = {"sample": 'Flat_10',"motor":25.0,"pos":1,"VOFFSET":80}
# pi.open_two_images(search_dict)


# # %%
# search_dict = {"sample": 'Flat_10',"motor": 15,"pos": 2, "VOFFSET": 0}
# pi.quick_piv_by_key(search_dict)

# # %%

# search_dict = {"sample": 'Flat_10','motor':5}
# [x for x in pi.param_dict_list if search_dict.items() <= x.items()]

# # %%
# pi.param_string_to_dictionary('Flat_10_motor5.00_pos2_VOFFSET0_01-18_ag2_laser10')


# # %%
# pi.param_string_list
# # %%
# len(pi.param_string_list)

# # %%
# len(os.listdir(folder_path))